#!/usr/bin/env node
/* War Room Discord Bot — links Discord ↔ intel server ↔ War Room
   Setup: npm install discord.js   then EITHER:
     node discord-bot.js <DISCORD_BOT_TOKEN> <INTEL_SERVER_URL> [key]
   OR set env vars (better for hosting): DISCORD_BOT_TOKEN, INTEL_SERVER_URL, INTEL_KEY  then: node discord-bot.js
   e.g. node discord-bot.js abc123 http://localhost:8108 yourkey
   Commands: !intel <prov> · !recent · !help · paste any SoT/SoM/news text with !push to feed the site */
const TOKEN=process.env.DISCORD_BOT_TOKEN||process.argv[2];
const SERVER=process.env.INTEL_SERVER_URL||process.argv[3];
const KEY=process.env.INTEL_KEY||process.argv[4]||"";
if(!TOKEN||!SERVER){console.log("usage: node discord-bot.js <token> <serverUrl> [key]   (or set DISCORD_BOT_TOKEN / INTEL_SERVER_URL / INTEL_KEY env vars)");process.exit(1);}
const {Client,GatewayIntentBits}=require("discord.js");
const bot=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent]});
const base=SERVER.replace(/\/+$/,""), k=KEY?`&key=${encodeURIComponent(KEY)}`:"";
async function feed(){const r=await fetch(`${base}/feed?since=0${k}`);return (await r.json()).entries||[];}
bot.on("messageCreate",async m=>{
  if(m.author.bot)return; const t=m.content.trim();
  try{
    const state=async()=>{const r=await fetch(`${base}/state?x=1${k}`);return await r.json();};
    const fk=n=>{n=+n||0;return Math.abs(n)>=1e6?(n/1e6).toFixed(1)+"M":Math.abs(n)>=1e3?Math.round(n/1e3)+"k":""+Math.round(n);};
    const ment=p=>{const d=((p&&p.discord)||"").trim();if(!d)return"";const id=d.replace(/[<@!>]/g,"");return /^\d{5,}$/.test(id)?` <@${id}>`:` ${d.startsWith("@")?d:"@"+d}`;};
    if(t==="!help") return m.reply("**SavageDomain bot**\n`!intel <prov>` latest raw intel · `!recent` last ops · `!push <text>` feed intel to the site\n`!wave` current wave plan · `!targets` my target list · `!prov <name>` stored stats\n`!kd` totals · `!tms` enemy TMs · `!left` offense left · `!sci <prov>` science · `!sim [target]` wave outcome · `!eco [hours]` economy sim · `!status <prov>` full status card\n`!assign` who-hits-what (with bounce check) · `!chains` chain send-order");
    if(t==="!wave"){const s=await state();const e=s.enemies?.[s.activeEnemy];if(!e?.wave?.length)return m.reply("No wave planned.");
      const nm=id=>s.myKd.provinces.find(p=>p.id===id)?.name||"?", tn=id=>e.provinces.find(p=>p.id===id)?.name||"?";
      const L=c=>e.wave.filter(w=>w.cat===c).map(w=>`• ${nm(w.attacker)} → ${tn(w.target)} (${w.cat==="tm"?w.op:(w.type+" "+fk(w.off))})`).join("\n");
      return m.reply(`**Wave vs ${e.name}** (${e.wave.length})\n🟡 Mass:\n${L("mass")||"—"}\n🔴 Chain:\n${L("chain")||"—"}\n🔵 TM:\n${L("tm")||"—"}`.slice(0,1900));}
    if(t==="!assign"){const s=await state();const e=s.enemies?.[s.activeEnemy];if(!e?.wave?.length)return m.reply("No wave planned.");
      const myP=id=>s.myKd.provinces.find(p=>p.id===id), tn=id=>e.provinces.find(p=>p.id===id)?.name||"?";
      const byA={};e.wave.forEach(w=>{(byA[w.attacker]=byA[w.attacker]||[]).push(w);});
      const lines=Object.keys(byA).map(aid=>{const a=myP(aid);
        const hl=byA[aid].map(w=>{const tp=e.provinces.find(p=>p.id===w.target)||{};
          if(w.cat==="tm")return `   → ${tn(w.target)} (TM ${w.type||w.op||""})`;
          const mod=(+w.off||0)*(1+0.05*Math.max(0,(+w.gens||1)-1));
          const need=w.type==="conquest"?(+tp.defense||0)*0.51:(+tp.defense||0);
          return `   → ${tn(w.target)} (${w.type} ${fk(w.off)} ${mod>need?"✅":"❌ bounce"})`;}).join("\n");
        return `**${a?.name||"?"}**${ment(a)}\n${hl}`;}).join("\n");
      return m.reply(`📋 **Assignments vs ${e.name}**\n${lines}`.slice(0,1900));}
    if(t==="!chains"){const s=await state();const e=s.enemies?.[s.activeEnemy];if(!e?.wave?.length)return m.reply("No wave planned.");
      const myP=id=>s.myKd.provinces.find(p=>p.id===id), tn=id=>e.provinces.find(p=>p.id===id)?.name||"?", war=e.warMode==="in";
      const atime=a=>{let x=14;if(war)x*=0.85;if(a?.race==="Avian")x*=0.8;if(a?.race==="Dwarf")x*=1.1;if(a?.pers==="Tactician")x*=0.85;return Math.round(x*10)/10;};
      const byT={};e.wave.filter(w=>w.cat==="chain").forEach(w=>{(byT[w.target]=byT[w.target]||[]).push(w);});
      const blocks=Object.keys(byT).filter(tid=>byT[tid].length>1).map(tid=>{
        const hits=byT[tid].map(w=>({n:myP(w.attacker)?.name||"?",t:atime(myP(w.attacker))})).sort((a,b)=>b.t-a.t);
        return `⛓ **${tn(tid)}** — send slowest first:\n`+hits.map((h,i)=>`   ${i+1}. ${h.n} (${h.t}t)`).join("\n");});
      return m.reply(blocks.length?blocks.join("\n").slice(0,1900):"No chains (targets with 2+ hits) in this wave.");}
    if(t==="!targets"){const s=await state();const e=s.enemies?.[s.activeEnemy];if(!e)return m.reply("No active enemy.");
      const r=(e.targets||[]).map(id=>e.provinces.find(p=>p.id===id)).filter(Boolean).map(p=>`• ${p.name} — def ${fk(p.defense)} · NW ${fk(p.nw)}${p.armyOut?" · OUT":""}`).join("\n");
      return m.reply(r?`**My Targets (${e.name})**\n${r}`:"No targets starred.");}
    if(t.startsWith("!prov ")){const q=t.slice(6).toLowerCase();const s=await state();
      const all=[...(s.myKd?.provinces||[]).map(p=>({...p,side:"mine"})),...Object.values(s.enemies||{}).flatMap(e=>e.provinces.map(p=>({...p,side:e.name})))];
      const p=all.find(x=>x.name.toLowerCase().includes(q));if(!p)return m.reply("Not found.");
      return m.reply(`**${p.name}** (${p.side}) ${p.race||""} ${p.pers||""}\nNW ${fk(p.nw)} · ${fk(p.land)}A · off ${fk(p.offense)} · def ${fk(p.defense)} · TPA ${p.tpa||"?"} · WPA ${p.wpa||"?"}${p.armyOut?` · ⚔ OUT t${p.returnTick||"?"}`:""}`);}
    if(t==="!kd"){const s=await state();const e=s.enemies?.[s.activeEnemy];const tot=ps=>ps.reduce((a,p)=>a+(+p.nw||0),0);
      return m.reply(`🛡 **${s.myKd.name}** ${s.myKd.provinces.length} provs · NW ${fk(tot(s.myKd.provinces))}\n🎯 **${e?.name||"—"}** ${e?.provinces.length||0} provs · NW ${fk(tot(e?.provinces||[]))}`);}
    if(t==="!tms"){const s=await state();const e=s.enemies?.[s.activeEnemy];if(!e)return m.reply("No active enemy.");
      const r=e.provinces.filter(p=>(+p.offense||0)<(+p.defense||0)*0.15).map(p=>`• ${p.name} — def ${fk(p.defense)} · TPA ${p.tpa||"?"} · WPA ${p.wpa||"?"}`).join("\n");
      return m.reply(r?`**Enemy TMs**\n${r}`:"No TMs detected.");}
    if(t.startsWith("!sci ")){const q=t.slice(5).toLowerCase();const s=await state();
      const all=[...(s.myKd?.provinces||[]),...Object.values(s.enemies||{}).flatMap(e=>e.provinces)];
      const p=all.find(x=>x.name.toLowerCase().includes(q));
      if(!p)return m.reply("Not found.");if(!p.sci)return m.reply(`No science intel stored for **${p.name}**.`);
      const rows=Object.entries(p.sci).filter(([k,v])=>v!==null&&v!=="").map(([k,v])=>`${k}: ${v}`).join(" · ");
      return m.reply(`🔬 **${p.name}** science\n${rows}`.slice(0,1900));}
    if(t==="!sim"||t.startsWith("!sim ")){const q=t.slice(4).trim().toLowerCase();const s=await state();
      const e=s.enemies?.[s.activeEnemy];if(!e?.wave?.length)return m.reply("No wave planned to simulate.");
      const war=e.warMode==="in";const myP=id=>s.myKd.provinces.find(p=>p.id===id);
      const tgts={};e.wave.filter(w=>w.cat!=="tm").forEach(w=>{(tgts[w.target]=tgts[w.target]||[]).push(w);});
      let out=[],totGain=0,totLoss=0,kP=0,kT=0,kW=0;
      for(const[tid,hits]of Object.entries(tgts)){
        const tp=e.provinces.find(p=>p.id===tid);if(!tp)continue;
        if(q&&!tp.name.toLowerCase().includes(q))continue;
        let land=+tp.land||0,lost=0,brk=0;
        for(const w of hits){
          const mod=(+w.off||0)*(1+0.05*Math.max(0,(+w.gens||1)-1));
          const need=w.type==="conquest"?(+tp.defense||0)*0.51:(+tp.defense||0);
          if(mod<=need)continue;brk++;
          const pct={march:.12,conquest:.068,raze:.05}[w.type]||0;
          let g=land*pct*(war?1.10:1);g=Math.min(g,land*0.20);
          if(w.type==="raze"){lost+=g;land-=g;}
          else if(pct){lost+=g;land-=g;totGain+=g;}
          totLoss+=(+w.off||0)*0.075;
          if(w.type==="massacre"){const tl=+tp.land||1,th=(+tp.tpa||0)*tl,wi=(+tp.wpa||0)*tl,pe=Math.max(0,(+tp.pop||0)-th-wi),x=war?2:1;
            kP+=pe*.095*x;kT+=th*.075*x;kW+=wi*.05*x;}
        }
        const mp=(+tp.maxpop||land*22)||1;const opPct=Math.round(((+tp.pop||0)/Math.max(1,(mp/(+tp.land||1))*land))*100);
        const op=opPct>140?"L4 no-thv":opPct>130?"L3 riot":opPct>115?"L2 no-atk":opPct>100?"L1":"ok";
        out.push(`• **${tp.name}**: ${brk}/${hits.length} break · −${Math.round(lost)}A → ${Math.round(land)}A · overpop ${opPct}% (${op})`);
      }
      if(!out.length)return m.reply("No matching targets in the wave.");
      const k=n=>Math.abs(n)>=1e3?Math.round(n/1e3)+"k":Math.round(n);
      return m.reply((`🔮 **Wave simulation vs ${e.name}** ${war?"(war gains)":""}\n`+out.join("\n")+
        `\n**Totals:** +${Math.round(totGain)}A captured · −${k(totLoss)} our troops lost`+
        ((kP+kT+kW)?` · 💀 ~${k(kP)} peas / ${k(kT)} thieves / ${k(kW)} wiz killed`:"")).slice(0,1900));}
    if(t==="!eco"||t.startsWith("!eco ")){const hrs=Math.max(1,Math.min(168,parseInt(t.slice(4))||24));const s=await state();
      const pick=(kd)=>kd&&kd.provinces.some(p=>p.sci&&(p.sci.peons||p.sci.farm!=null));
      const mineOk=pick(s.myKd), kd=mineOk?s.myKd:(s.enemies?.[s.activeEnemy]);
      if(!pick(kd))return m.reply("No economy intel stored — import a full intel CSV (Peons/Farm/Towe/BE columns).");
      let inc=0,food=0,eat=0,run=0,gc0=0,f0=0,r0=0,n=0;
      kd.provinces.forEach(p=>{const c=p.sci;if(!c)return;n++;
        const be=(c.be||100)/100, land=+p.land||0;
        inc+=(c.peons||0)*2.75*be;                       // ~2.75gc/peasant/tick × BE
        food+=land*((c.farm||0)/100)*70*be;              // 70 bushels/farm-acre/tick × BE
        eat+=((+p.pop||((c.peons||0)+(c.military||0)))*0.25);  // 0.25 bushels/person/tick
        run+=land*((c.towe||0)/100)*12*be;               // 12 runes/tower-acre/tick × BE
        gc0+=c.gcs||0; f0+=c.food||0; r0+=c.runes||0;});
      const gcGain=inc*hrs, foodNet=(food-eat)*hrs, runGain=run*hrs;
      const gcEnd=gc0+gcGain, k=v=>Math.abs(v)>=1e6?(v/1e6).toFixed(1)+"M":Math.abs(v)>=1e3?Math.round(v/1e3)+"k":Math.round(v);
      return m.reply(`📈 **${kd.name} — ${hrs}-tick economy sim** (${n} provs w/ intel)\n`+
        `💰 GC: ${k(gc0)} now → **${k(gcEnd)}** (+${k(gcGain)}, ~${k(inc)}/tick, wages not deducted)\n`+
        `🌾 Food: ${k(f0)} now → **${k(f0+foodNet)}** (net ${foodNet>=0?"+":""}${k(foodNet)}; prod ${k(food)}/t vs eaten ${k(eat)}/t${foodNet<0?" ⚠ STARVING":""})\n`+
        `🔮 Runes: ${k(r0)} now → **${k(r0+runGain)}** (+${k(runGain)})\n`+
        `⚔ Can afford with end GC: ~**${k(gcEnd/350)}** specs @350 · ~**${k(gcEnd/750)}** elites @~750 · ~**${k(gcEnd/1000)}** war horses @1k\n`+
        `_Estimates: 2.75gc/peas/t, 70 food/farm-acre/t, 12 runes/tower-acre/t, 0.25 food/person/t, all ×BE. Sci/dragons/rituals not modeled._`);}
    if(t.startsWith("!status ")){const q=t.slice(8).toLowerCase();const s=await state();const ents=await feed();
      const all=[...(s.myKd?.provinces||[]).map(p=>({...p,side:"🛡"})),...Object.values(s.enemies||{}).flatMap(e=>e.provinces.map(p=>({...p,side:"🎯 "+e.name})))];
      const p=all.find(x=>x.name.toLowerCase().includes(q));if(!p)return m.reply("Not found.");
      const fk=n=>{n=+n||0;return Math.abs(n)>=1e6?(n/1e6).toFixed(1)+"M":Math.abs(n)>=1e3?Math.round(n/1e3)+"k":""+Math.round(n);};
      const last=[...ents].reverse().find(x=>(x.data_simple||"").toLowerCase().includes(p.name.toLowerCase()));
      let sci="";if(p.sci){const top=Object.entries(p.sci).filter(([k,v])=>typeof v==="number"&&v>0&&!["be","wages","gcs","food","runes","peons","military","farm","towe","bank","mill","homes","guil","univ","libs"].includes(k)).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=>`${k}:${v}`).join(" | ");if(top)sci="\n🔬 "+top;}
      const army=p.armyOut?`⚔ OUT, returns tick ${p.returnTick||"?"}${p.incomingLand?` (+${fk(p.incomingLand)}A incoming)`:""}`:"⌂ home";
      return m.reply(`__**${p.name}**__ ${p.side} ${p.race||""}${p.pers?"/"+p.pers:""}\n`+
        `* nw:${fk(p.nw)} | off:${fk(p.offense)} | def:${fk(p.defense)}\n`+
        `* tpa:${p.tpa||"?"}${p.mdtpa?" (md "+p.mdtpa+")":""} | wpa:${p.wpa||"?"}${p.mdwpa?" (md "+p.mdwpa+")":""} | ${fk(p.land)}A | honor ${fk(p.honor)}\n`+
        `* ${army}${p.sci&&p.sci.be?` | BE ${p.sci.be}%`:""}${p.sci&&p.sci.peons?` | peons ${fk(p.sci.peons)}`:""}${sci}\n`+
        (last?`* last intel <t:${Math.floor(last.ts/1000)}:R>`:"* no raw intel logged yet")); }
    if(t==="!left"){const s=await state();const e=s.enemies?.[s.activeEnemy];
      const used={};(e?.wave||[]).forEach(w=>{used[w.attacker]=(used[w.attacker]||0)+(+w.off||0);});
      const r=s.myKd.provinces.map(p=>`• ${p.name}${ment(p)}: ${fk(Math.max(0,(+p.offense||0)-(used[p.id]||0)))} left`).join("\n");
      return m.reply(("**Offense left**\n"+r).slice(0,1900));}
    if(t==="!recent"){const e=await feed();const last=e.slice(-10).map(x=>`• <t:${Math.floor(x.ts/1000)}:R> ${x.prov||"?"} → ${(x.url||"").split("/").pop()}`).join("\n");return m.reply(last||"No intel received yet.");}
    if(t.startsWith("!intel ")){const q=t.slice(7).toLowerCase();const e=await feed();
      const hit=[...e].reverse().find(x=>(x.data_simple||"").toLowerCase().includes(q));
      return m.reply(hit?`Latest intel mentioning **${q}** (<t:${Math.floor(hit.ts/1000)}:R>):\n\`\`\`\n${hit.data_simple.slice(0,1500)}\n\`\`\``:`No stored intel mentions "${q}".`);}
    if(t.startsWith("!push")){const body=t.slice(5).trim()||"";if(!body)return m.reply("Paste the intel text after !push.");
      const r=await fetch(`${base}/post`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},
        body:new URLSearchParams({key:KEY,prov:m.author.username,url:"discord/push",data_simple:body})});
      const j=await r.json();return m.reply(j.success?"✅ Sent to the War Room — it'll apply on next sync (≤20s).":"❌ Server rejected it (key?).");}
  }catch(e){m.reply("⚠ Can't reach the intel server: "+e.message);}
});
bot.once("ready",()=>console.log("War Room bot online as",bot.user.tag));
bot.login(TOKEN);
